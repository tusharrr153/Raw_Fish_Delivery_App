package com.example.anaghafishapp.Interface;

public interface ChangeNumberItemsListener {

    void changed();
}
